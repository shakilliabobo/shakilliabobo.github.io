<!doctype html>
<html>

	<?php include 'inc/head.php';?>

	<body id="aboutMe">
		<div class="container-fluid header-BG">

			<div class="row header">
				<div class="col-md-3 logo-holder"><img src="img/shakillia-bobo-web-developer-name-title.png" class="img-responsive"/></div><div class="col-md-8 mainNav"><ul><li><a href="index.php">HOME</a></li><!--<li><a href="#">SERVICES</a></li>--><li><a href="#">PORTFOLIO</a></li><li><a href="#">CONTACT</a></li></ul></div>
			</div>
			<div class="row sub-header">

			</div>
	

		<div class="row box-container wrapper">
			<div class="col-md-2 meImg"><img src="img/shakillia-bobo-pic.png" class="brownBorder img-responsive"/></div><div class="col-md-8 aboutMe">	     	<h2>'She'll' 'Kill' 'Ya'</h2>
	     	<p>Pronounciation for my name. Yeah what a name, right? My mother was a huge Shaquille O' Neal fan back in the day. Contradicting to my name, you'll find that I am not a serial killer and that I absolutely suck at basketball! However, I am an experienced Web Developer born and raised in North Carolina. I specialize in CMS programs such as Wordpress and Joomla. I am knowledgable in HTML, CSS, and Javascript. I am also skilled in Search Engine Optimization and the Google Search Console. I have been working for a marketing design company, Freedom Creative Solutions for a little over two years now and am familiar with the kind of environment that comes with this field. Click below to see what else I have to offer! </p></div>
 	
		</div>
		<div style="clear:both;"></div>
			     	<div class="row box-container portfolioCallOut">
	     	           <h3>Click Here to See My Portfolio!</h3>
	     	</div>
      
        <div style="clear:both;"></div>
        <footer><p>Created by Shakillia Bobo &copy; 2017</p></footer>
        
	</body>
</html>
